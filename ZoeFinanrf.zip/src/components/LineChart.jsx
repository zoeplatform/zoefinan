// Arquivo removido em favor do MonthlyEvolution.jsx para melhor integração com os dados do projeto.
export default function LineChart() { return null; }
