/**
 * PÁGINA: Plano Estratégico
 * DESCRIÇÃO: Apresenta o plano de ação personalizado com base nos dados financeiros do usuário.
 * ---------------------------------------------------------
 */

import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ShieldCheck, Target, Lightning, Warning, Handshake } from "phosphor-react";
import { db, auth } from "../firebase";
import { doc, getDoc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { getCurrentMonthKey } from "../utils/dateUtils";
import { getRandomCardColor } from "../utils/themeUtils";

export default function Plano() {
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Cores dinâmicas para os cards de plano
  const cardColors = useMemo(() => ({
    reserva: getRandomCardColor("reserva"),
    controle: getRandomCardColor("controle"),
    aceleracao: getRandomCardColor("aceleracao"),
  }), []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const userRef = doc(db, "usuarios", user.uid);
          const docSnap = await getDoc(userRef);
          if (docSnap.exists()) setData(docSnap.data());
        } catch (error) {
          console.error("Erro ao buscar plano:", error);
        } finally {
          setLoading(false);
        }
      } else {
        navigate("/login");
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  if (loading) {
    return (
      <div className="h-screen bg-surface flex items-center justify-center text-on-surface-variant">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-on-surface-variant mr-3" />
        Carregando seu plano...
      </div>
    );
  }

  /* 
     LÓGICA DE CÁLCULO: Processamento dos dados para o plano
     -------------------------------------------------------
  */
  const currentMonth = getCurrentMonthKey();
  const monthData = data?.historicoMensal?.[currentMonth];

  const rendaBaseMes = Number(monthData?.rendaBase) || 0;
  const rendasExtrasMes = monthData?.rendasExtras?.reduce((acc, curr) => acc + (Number(curr.valor) || 0), 0) || 0;
  const renda = (rendaBaseMes + rendasExtrasMes) || Number(data?.rendaMensal) || 0;
  
  const despesas = (monthData?.despesas && monthData.despesas.length > 0) 
    ? monthData.despesas 
    : (data?.despesasFixas || []);
    
  const dividas = (monthData?.dividas && monthData.dividas.length > 0)
    ? monthData.dividas
    : (data?.dividas || []);

  // Categorias de sobrevivência
  const categoriasSobrevivencia = ["alimentação", "moradia", "água", "luz", "aluguel", "energia", "internet"];
  
  const despesasSobrevivencia = despesas.filter(d => 
    categoriasSobrevivencia.some(cat => d.descricao?.toLowerCase().includes(cat))
  ).reduce((sum, d) => sum + (Number(d?.valor) || 0), 0);

  const outrasDespesas = despesas.filter(d => 
    !categoriasSobrevivencia.some(cat => d.descricao?.toLowerCase().includes(cat))
  ).reduce((sum, d) => sum + (Number(d?.valor) || 0), 0);

  const totalDespesas = despesasSobrevivencia + outrasDespesas;
  const totalParcelas = dividas.reduce((sum, d) => sum + (Number(d?.parcela) || 0), 0);

  // Lógica de Prioridade: Renda -> Sobrevivência -> Outras Despesas -> Dívidas
  const saldoAposSobrevivencia = Math.max(renda - despesasSobrevivencia, 0);
  const saldoLivreReal = Math.max(saldoAposSobrevivencia - outrasDespesas - totalParcelas, 0);

  const metaReserva = totalDespesas * 6;
  const sugestaoReservaMensal = renda > 0 ? renda * 0.10 : 0;

  const limiteGastos = renda * 0.5;
  const excessoGastos = totalDespesas > limiteGastos ? totalDespesas - limiteGastos : 0;

  // Estratégia de Dívidas: Se o orçamento é baixo, foca em renegociar as não parceladas
  const dividasNaoParceladas = dividas.filter(d => !d.isParcelada);
  const dividasParceladas = dividas.filter(d => d.isParcelada);
  
  const ataqueDividas = saldoLivreReal > 0 ? saldoLivreReal * 0.7 : 0;

  return (
    <div className="min-h-screen bg-surface px-6 pt-8 pb-32 md:pb-8 relative overflow-hidden transition-colors duration-300">
      {/* BACKGROUND: Elementos visuais premium */}
      <div className="pointer-events-none absolute inset-0 dark:block hidden">
        <div className="absolute -top-24 -left-24 h-[320px] w-[320px] rounded-full bg-white/5 blur-3xl" />
        <div className="absolute -bottom-32 -right-24 h-[420px] w-[420px] rounded-full bg-white/5 blur-3xl" />
        <div className="absolute left-1/2 top-[10%] -translate-x-1/2 h-[500px] w-[500px] rounded-full bg-gradient-to-b from-orange-500/20 via-purple-500/15 to-blue-500/15 blur-[100px] opacity-40" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* HEADER */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate(-1)}
            className="h-12 w-12 rounded-2xl shadow-sm dark:shadow-none --app-background dark:bg-surface-high border border-default flex items-center justify-center active:scale-95 transition-all md:hidden"
          >
            <ArrowLeft size={20} className="text-on-surface" />
          </button>
          <div>
            <h1 className="text-2xl font-black text-on-surface tracking-tight uppercase">Plano Estratégico</h1>
            <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-[0.2em]">Foco em Quitação e Sobrevivência</p>
          </div>
        </div>

        {/* ALERTA DE ORÇAMENTO BAIXO */}
        {saldoAposSobrevivencia < (outrasDespesas + totalParcelas) && (
          <div className="mb-8 p-6 rounded-[32px] bg-error-bg border border-error/20 flex items-start gap-4 animate-pulse">
            <Warning size={32} className="text-error shrink-0" weight="fill" />
            <div>
              <h4 className="text-sm font-black text-error uppercase tracking-tight">Alerta de Orçamento Crítico</h4>
              <p className="text-xs text-error/80 mt-1 leading-relaxed">
                Sua renda atual mal cobre as despesas de sobrevivência e parcelas. <strong>Não utilize seu saldo de alimentação/moradia para pagar dívidas totais agora.</strong> Foque em renegociar o que não está parcelado.
              </p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* CARD 1: Reserva de Segurança */}
          <div className={`rounded-[32px] border border-default p-8 shadow-xl dark:shadow-none h-full transition-all duration-300 
            dark:bg-surface-high ${cardColors.reserva.bg}`}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-white/20 dark:bg-info-bg border border-white/20 dark:border-info/20 flex items-center justify-center text-white dark:text-info">
                  <ShieldCheck size={24} weight="duotone" />
                </div>
                <h3 className="text-sm font-black text-white dark:text-on-surface uppercase tracking-wider">Segurança</h3>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-black/10 dark:bg-black/10 p-4 rounded-2xl border border-white/10 dark:border-default">
                <p className="text-[10px] text-white/70 dark:text-on-surface-variant uppercase font-black mb-1">Custo de Sobrevivência</p>
                <p className="text-lg font-black text-white dark:text-on-surface">R$ {(despesasSobrevivencia || 0).toLocaleString("pt-BR")}</p>
              </div>
              <div className="bg-black/10 dark:bg-black/10 p-4 rounded-2xl border border-white/10 dark:border-default">
                <p className="text-[10px] text-white/70 dark:text-on-surface-variant uppercase font-black mb-1">Aporte Sugerido</p>
                <p className="text-lg font-black text-white dark:text-success">R$ {(sugestaoReservaMensal || 0).toLocaleString("pt-BR")}</p>
              </div>
              <p className="text-xs text-white/80 dark:text-on-surface-variant leading-relaxed">
                Priorize manter R$ {(despesasSobrevivencia || 0).toLocaleString('pt-BR')} intocáveis para o básico.
              </p>
            </div>
          </div>

          {/* CARD 2: Otimização */}
          <div className={`rounded-[32px] border border-default p-8 shadow-xl dark:shadow-none h-full transition-all duration-300 
            dark:bg-surface-high ${cardColors.controle.bg}`}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-white/20 dark:bg-warning-bg border border-white/20 dark:border-warning/20 flex items-center justify-center text-white dark:text-warning">
                  <Target size={24} weight="duotone" />
                </div>
                <h3 className="text-sm font-black text-white dark:text-on-surface uppercase tracking-wider">Otimização</h3>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-white/80 dark:text-on-surface-variant">Outras Despesas</span>
                <span className="font-bold text-white dark:text-on-surface">R$ {(outrasDespesas || 0).toLocaleString("pt-BR")}</span>
              </div>
              <div className="w-full bg-black/20 dark:bg-surface-highest h-2 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-1000 ${outrasDespesas > (renda * 0.2) ? 'bg-red-400' : 'bg-green-400'}`}
                  style={{ width: `${Math.min((outrasDespesas / (renda || 1)) * 100, 100)}%` }}
                />
              </div>
              <p className="text-xs text-white/80 dark:text-on-surface-variant leading-relaxed">
                Tente manter gastos não essenciais abaixo de 20% da renda para sobrar para as dívidas.
              </p>
            </div>
          </div>

          {/* CARD 3: Aceleração (Dívidas) */}
          <div className={`rounded-[32px] border border-default p-8 shadow-xl dark:shadow-none h-full transition-all duration-300 
            dark:bg-surface-high ${cardColors.aceleracao.bg}`}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-white/20 dark:bg-accent-primary/10 border border-white/20 dark:border-accent-primary/20 flex items-center justify-center text-white dark:text-accent-primary">
                  <Lightning size={24} weight="duotone" />
                </div>
                <h3 className="text-sm font-black text-white dark:text-on-surface uppercase tracking-wider">Quitação</h3>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-white/80 dark:text-on-surface-variant">Saldo para Ataque</span>
                <span className="font-black text-white dark:text-success">R$ {(ataqueDividas || 0).toLocaleString("pt-BR")}</span>
              </div>
              
              {dividas.length > 0 ? (
                <div className="space-y-4">
                  <div className="space-y-2 max-h-[200px] overflow-y-auto no-scrollbar">
                    {dividasNaoParceladas.map((d, idx) => (
                      <div key={idx} className="p-4 rounded-2xl bg-error-bg/20 border border-error/20">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-black text-error uppercase">Renegociar</span>
                          <Handshake size={16} className="text-error" />
                        </div>
                        <p className="text-sm font-bold text-white dark:text-on-surface">{d.credor}</p>
                        <p className="text-[10px] text-white/60 dark:text-on-surface-variant mt-1">
                          Esta dívida não está parcelada. Entre em contato para transformar o saldo de R$ {(d.saldo || 0).toLocaleString('pt-BR')} em parcelas que caibam no seu saldo livre.
                        </p>
                      </div>
                    ))}
                    
                    {dividasParceladas.map((d, idx) => (
                      <div key={idx} className="flex items-center justify-between p-4 rounded-2xl bg-black/10 dark:bg-surface-highest border border-white/10 dark:border-default">
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold text-white dark:text-on-surface-medium">{d.credor}</span>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-black text-white dark:text-on-surface">R$ {(d.parcela || 0).toLocaleString("pt-BR")}</p>
                          <p className="text-[8px] text-white/40 uppercase font-black">Parcela</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-black/10 dark:bg-info-bg border border-white/10 dark:border-info/20">
                  <p className="text-xs text-white dark:text-info leading-relaxed">
                    Nenhuma dívida ativa! Use seu saldo livre para investir.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* BOTÃO: Finalização */}
        <button
          onClick={() => navigate("/home")}
          className="w-full mt-10 rounded-[24px] bg-on-surface text-surface-lowest dark:bg-white dark:text-black py-5 font-black text-xs uppercase tracking-[0.2em] active:scale-95 transition-all shadow-xl"
        >
          Finalizar Consultoria
        </button>
      </div>
    </div>
  );
}
