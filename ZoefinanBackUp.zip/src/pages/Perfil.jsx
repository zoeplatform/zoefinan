// src/pages/Perfil.jsx
/**
 * PÁGINA: Perfil do Usuário
 * DESCRIÇÃO: Gerenciamento de conta, preferências de tema, reserva de emergência e backup.
 * ---------------------------------------------------------
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  CaretRight,
  Bank,
  Plus,
  DownloadSimple,
  UploadSimple,
  Trash,
  Warning,
  Moon,
  Sun,
} from "phosphor-react";

import { auth, db } from "../firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { exportUserData, importUserData } from "../utils/backupUtils";

export default function Perfil() {
  const navigate = useNavigate();

  const [entered, setEntered] = useState(false);
  const [loading, setLoading] = useState(true);

  const [reserva, setReserva] = useState(0);
  const [metaSugerida, setMetaSugerida] = useState(10000);

  const [novoValor, setNovoValor] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const [backupLoading, setBackupLoading] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Preferência de tema: padrão é DARK
  const [isDark, setIsDark] = useState(() => {
    const saved = localStorage.getItem("zoe-theme");
    return saved === null ? true : saved === "dark";
  });

  const fileInputRef = useRef(null);
  const [user, setUser] = useState(auth.currentUser);

  /**
   * CARREGAMENTO DE DADOS
   */
  useEffect(() => {
    let mounted = true;

    async function carregarDados(uid) {
      try {
        const userRef = doc(db, "usuarios", uid);
        const docSnap = await getDoc(userRef);

        if (!mounted) return;

        if (docSnap.exists()) {
          const data = docSnap.data();

          setReserva(data.reservaEmergencia || 0);

          const despesasFixas = data.despesasFixas || [];
          const totalDespesas = despesasFixas.reduce(
            (sum, d) => sum + (Number(d?.valor) || 0),
            0
          );

          if (totalDespesas > 0) setMetaSugerida(totalDespesas * 6);
        }
      } catch (e) {
        console.error("Erro ao carregar dados do perfil:", e);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    const unsubscribe = onAuthStateChanged(auth, (u) => {
      if (u) {
        setUser(u);
        carregarDados(u.uid);
      } else {
        navigate("/login");
      }
    });

    const raf = requestAnimationFrame(() => setEntered(true));

    return () => {
      mounted = false;
      unsubscribe();
      cancelAnimationFrame(raf);
    };
  }, [navigate]);

  /**
   * AÇÕES
   */
  const toggleTheme = () => {
    const newTheme = isDark ? "light" : "dark";
    setIsDark((prev) => !prev);
    localStorage.setItem("zoe-theme", newTheme);
    window.dispatchEvent(new Event("themeChanged"));
  };

  async function handleAddReserva() {
    if (!user) return;

    const valorNum = Number(String(novoValor).replace(",", "."));
    if (!novoValor || Number.isNaN(valorNum) || valorNum <= 0) return;

    const total = reserva + valorNum;

    try {
      const userRef = doc(db, "usuarios", user.uid);
      await updateDoc(userRef, { reservaEmergencia: total });
      setReserva(total);
      setNovoValor("");
      setShowAdd(false);
    } catch (e) {
      console.error("Erro ao atualizar reserva:", e);
    }
  }

  async function handleSair() {
    try {
      await signOut(auth);
      navigate("/login");
    } catch (e) {
      console.error("Erro ao sair:", e);
    }
  }

  async function handleExportBackup() {
    if (!user) return;
    setBackupLoading(true);
    try {
      await exportUserData(user.uid);
    } catch (error) {
      alert("Erro ao exportar backup: " + (error?.message || error));
    } finally {
      setBackupLoading(false);
    }
  }

  async function handleImportBackup(event) {
    const file = event?.target?.files?.[0];
    if (!file || !user) return;

    const ok = window.confirm(
      "Isso irá sobrescrever seus dados atuais. Deseja continuar?"
    );
    if (!ok) return;

    setBackupLoading(true);
    try {
      await importUserData(user.uid, file);
      alert("Backup restaurado com sucesso!");
      window.location.reload();
    } catch (error) {
      alert("Erro ao importar backup: " + (error?.message || error));
    } finally {
      setBackupLoading(false);
      // Limpa input para permitir re-upload do mesmo arquivo
      if (event?.target) event.target.value = "";
    }
  }

  async function handleResetAccount() {
    if (!user) return;

    const ok = window.confirm(
      "Tem certeza? Isso apagará seus dados e reiniciará sua conta."
    );
    if (!ok) return;

    setBackupLoading(true);
    try {
      const userRef = doc(db, "usuarios", user.uid);
      await updateDoc(userRef, {
        historicoMensal: {},
        rendaMensal: 0,
        despesasFixas: [],
        dividas: [],
        reservaEmergencia: 0,
        setupConcluido: false,
        reiniciadoEm: new Date(),
      });

      navigate("/setup");
    } catch (error) {
      console.error("Erro ao reiniciar conta:", error);
    } finally {
      setBackupLoading(false);
      setShowResetConfirm(false);
    }
  }

  /**
   * DERIVADOS
   */
  const nome = user?.displayName || "Usuário";
  const email = user?.email || "Sem e-mail";
  const uid = user?.uid || "";

  const iniciais = useMemo(() => {
    const base = (nome || email || "U").trim();
    const parts = base.split(" ").filter(Boolean);
    const a = (parts[0]?.[0] || "U").toUpperCase();
    const b = (parts[1]?.[0] || parts[0]?.[1] || "").toUpperCase();
    return `${a}${b}`;
  }, [nome, email]);

  /**
   * ESTILOS
   */
  const cardBase =
    "rounded-[32px] bg-surface-low dark:bg-surface-high border border-default shadow-xl dark:shadow-none backdrop-blur-xl transition-all duration-300";

  /**
   * Sub-componente: item clicável
   */
  const Item = ({
    icon,
    title,
    subtitle,
    onClick,
    danger,
    loading: itemLoading,
    rightElement,
  }) => (
    <button
      type="button"
      onClick={onClick}
      disabled={itemLoading}
      className={`w-full text-left ${cardBase} p-6 active:scale-[0.99] transition disabled:opacity-50 group`}
    >
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-start gap-4 min-w-0">
          <div
            className={`mt-0.5 h-12 w-12 rounded-2xl flex items-center justify-center border transition-colors ${
              danger
                ? "bg-error-bg border-error/20 text-error"
                : "bg-surface-high dark:bg-surface-highest border-default text-on-surface-variant group-hover:text-on-surface"
            }`}
          >
            {itemLoading ? (
              <div className="h-5 w-5 border-2 border-on-surface-disabled border-t-on-surface rounded-full animate-spin" />
            ) : (
              icon
            )}
          </div>

          <div className="min-w-0">
            <div
              className={`text-sm font-black uppercase tracking-tight ${
                danger ? "text-error" : "text-on-surface"
              }`}
            >
              {title}
            </div>
            {subtitle && (
              <div className="mt-1 text-[10px] font-bold uppercase tracking-widest text-on-surface-variant line-clamp-1">
                {subtitle}
              </div>
            )}
          </div>
        </div>

        <div className={`${danger ? "text-error/80" : "text-on-surface-variant"}`}>
          {rightElement || <CaretRight size={18} weight="bold" />}
        </div>
      </div>
    </button>
  );

  return (
    <div className="min-h-screen bg-surface relative overflow-hidden md:overflow-auto transition-colors duration-300">
   

      <div
        className={`relative z-10 w-full max-w-2xl mx-auto px-6 pt-8 pb-32 md:pb-8 transition-all duration-500 ${
          entered ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
        }`}
      >
        {/* HEADER */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate(-1)}
            className="h-12 w-12 rounded-2xl bg-surface-low dark:bg-surface-high border border-default flex items-center justify-center active:scale-95 transition-all md:hidden shadow-sm dark:shadow-none"
          >
            <ArrowLeft size={20} className="text-on-surface" />
          </button>

          <div className="min-w-0">
            <h1 className="text-2xl font-black text-on-surface tracking-tight uppercase">
              Perfil
            </h1>
            <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-[0.2em]">
              Gerenciamento de conta
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* COLUNA ESQUERDA */}
          <div className="space-y-6">
            {/* CARD: Info do usuário */}
            <div className={`${cardBase} p-8`}>
              <div className="flex items-center gap-5">
                <div className="h-16 w-16 rounded-[20px] bg-surface-high dark:bg-surface-highest border border-default flex items-center justify-center shadow-inner">
                  <span className="text-xl text-on-surface font-black">
                    {iniciais}
                  </span>
                </div>
                <div className="min-w-0">
                  <div className="text-lg text-on-surface font-black uppercase tracking-tight truncate">
                    {nome}
                  </div>
                  <div className="text-xs text-on-surface-variant font-medium truncate">
                    {email}
                  </div>
                </div>
              </div>

              {uid && (
                <div className="mt-6 pt-6 border-t border-default">
                  <p className="text-[8px] text-on-surface-disabled font-black uppercase tracking-widest">
                    Identificador Único
                  </p>
                  <p className="text-[10px] text-on-surface-variant font-mono break-all mt-1">
                    {uid}
                  </p>
                </div>
              )}
            </div>

            {/* CARD: Reserva */}
            <div className={`${cardBase} p-8`}>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-2xl bg-info-bg border border-info/20 flex items-center justify-center text-info">
                    <Bank size={24} weight="duotone" />
                  </div>

                  <div>
                    <h3 className="text-[10px] font-black text-on-surface-variant uppercase tracking-widest">
                      Reserva Atual
                    </h3>
                    <p className="text-2xl font-black text-on-surface">
                      R${" "}
                      {reserva.toLocaleString("pt-BR", {
                        minimumFractionDigits: 2,
                      })}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setShowAdd((s) => !s)}
                  className="h-10 w-10 rounded-xl bg-surface-high dark:bg-surface-highest border border-default flex items-center justify-center text-on-surface hover:scale-110 transition-transform"
                  aria-label="Adicionar valor à reserva"
                >
                  <Plus size={20} weight="bold" />
                </button>
              </div>

              {showAdd && (
                <div className="mb-6 p-4 bg-surface-high dark:bg-black/20 rounded-2xl border border-default animate-in fade-in slide-in-from-top-2">
                  <p className="text-[10px] font-black text-on-surface-variant uppercase mb-2">
                    Adicionar Valor
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={novoValor}
                      onChange={(e) => setNovoValor(e.target.value)}
                      placeholder="0,00"
                      className="flex-1 --app-background dark:bg-surface-high border border-default rounded-xl px-4 py-2 text-sm text-on-surface outline-none focus:border-accent-primary"
                    />
                    <button
                      onClick={handleAddReserva}
                      className="bg-on-surface text-surface-lowest dark:bg-white dark:text-black px-4 rounded-xl font-black text-[10px]"
                    >
                      OK
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-on-surface-variant uppercase">
                    Meta Sugerida
                  </span>
                  <span className="text-xs font-bold text-on-surface">
                    R$ {metaSugerida.toLocaleString("pt-BR")}
                  </span>
                </div>

                <div className="h-2 w-full bg-surface-high dark:bg-surface-highest rounded-full overflow-hidden">
                  <div
                    className="h-full bg-info transition-all duration-1000"
                    style={{
                      width: `${Math.min(
                        (reserva / (metaSugerida || 1)) * 100,
                        100
                      )}%`,
                    }}
                  />
                </div>

                <p className="text-[10px] text-on-surface-variant font-medium leading-relaxed">
                  Sua meta é baseada em 6 meses de suas despesas fixas atuais.
                </p>
              </div>
            </div>
          </div>

          {/* COLUNA DIREITA */}
          <div className="space-y-4">
            <Item
              icon={
                isDark ? (
                  <Moon size={22} weight="duotone" />
                ) : (
                  <Sun size={22} weight="duotone" />
                )
              }
              title="Tema da Interface"
              subtitle={isDark ? "Modo Escuro Ativado" : "Modo Claro Ativado"}
              onClick={toggleTheme}
              rightElement={
                <div
                  className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ${
                    isDark ? "bg-accent-primary" : "bg-surface-highest"
                  }`}
                >
                  <div
                    className={`w-4 h-4 bg-white rounded-full transition-transform duration-300 ${
                      isDark ? "translate-x-6" : "translate-x-0"
                    }`}
                  />
                </div>
              }
            />

            <Item
              icon={<DownloadSimple size={22} weight="duotone" />}
              title="Exportar Backup"
              subtitle="Salvar seus dados localmente"
              onClick={handleExportBackup}
              loading={backupLoading}
            />

            <div className="relative">
              <Item
                icon={<UploadSimple size={22} weight="duotone" />}
                title="Importar Backup"
                subtitle="Restaurar dados de um arquivo"
                onClick={() => fileInputRef.current?.click()}
                loading={backupLoading}
              />
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImportBackup}
                accept=".json"
                className="hidden"
              />
            </div>

            <div className="pt-4">
              {!showResetConfirm ? (
                <Item
                  icon={<Trash size={22} weight="duotone" />}
                  title="Reiniciar Conta"
                  subtitle="Apagar todos os dados e recomeçar"
                  onClick={() => setShowResetConfirm(true)}
                  danger
                />
              ) : (
                <div className={`${cardBase} p-6 border-error/30 bg-error-bg/5`}>
                  <div className="flex items-center gap-3 text-error mb-4">
                    <Warning size={24} weight="fill" />
                    <p className="text-xs font-black uppercase tracking-tight">
                      Tem certeza absoluta?
                    </p>
                  </div>

                  <p className="text-[10px] text-on-surface-variant font-medium mb-6 leading-relaxed">
                    Esta ação é irreversível. Todos os seus lançamentos, histórico
                    e configurações serão apagados permanentemente.
                  </p>

                  <div className="flex gap-3">
                    <button
                      onClick={handleResetAccount}
                      disabled={backupLoading}
                      className="flex-1 bg-error text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-error/90 transition disabled:opacity-60"
                    >
                      Sim, Reiniciar
                    </button>

                    <button
                      onClick={() => setShowResetConfirm(false)}
                      disabled={backupLoading}
                      className="flex-1 py-3 rounded-xl bg-surface-high dark:bg-surface-highest text-on-surface font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all disabled:opacity-60"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Ação extra útil: sair */}
            <button
              type="button"
              onClick={handleSair}
              className="mt-2 w-full py-4 rounded-2xl bg-surface-low dark:bg-surface-high border border-default text-on-surface font-black text-xs uppercase tracking-widest active:scale-95 transition-all"
            >
              Sair da Conta
            </button>
          </div>
        </div>

        {!loading && (
          <p className="mt-12 text-center text-[10px] font-black text-on-surface-disabled uppercase tracking-[0.3em]">
            ZoeFinan • Versão 1.1.0 • {new Date().getFullYear()}
          </p>
        )}
      </div>
    </div>
  );
}
